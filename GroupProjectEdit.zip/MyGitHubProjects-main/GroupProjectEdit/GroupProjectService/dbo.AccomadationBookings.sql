﻿CREATE TABLE [dbo].[Bookings] (
    [BookingsId]  INT          NOT NULL,
    [BookingDate] VARCHAR (50) NULL,
    [Booking]     NCHAR (10)   NULL,
    PRIMARY KEY CLUSTERED ([BookingsId] ASC)
);

