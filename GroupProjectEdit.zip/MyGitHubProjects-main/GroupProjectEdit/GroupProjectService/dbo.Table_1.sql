﻿CREATE TABLE [dbo].[Rooms]
(
	[RoomId] INT NOT NULL PRIMARY KEY, 
    [AccomadationId] INT NULL
)
