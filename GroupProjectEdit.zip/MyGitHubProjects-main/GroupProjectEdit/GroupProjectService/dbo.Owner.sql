﻿CREATE TABLE [dbo].[Owner] (
    [OwnerID]      INT          NOT NULL,
    [OwnerContact] VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([OwnerID] ASC)
);

