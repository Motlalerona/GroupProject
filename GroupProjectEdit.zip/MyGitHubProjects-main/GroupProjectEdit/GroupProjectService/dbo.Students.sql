﻿CREATE TABLE [dbo].[Students] (
    [StudentId]      INT          NOT NULL,
    [BookingId]      INT          NULL,
    [UserId]         INT          NULL,
    PRIMARY KEY CLUSTERED ([StudentId] ASC)
);

