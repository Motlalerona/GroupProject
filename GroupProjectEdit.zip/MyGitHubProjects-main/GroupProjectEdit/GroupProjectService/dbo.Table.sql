﻿CREATE TABLE [dbo].[BookMarks]
(
	[UserId] INT NOT NULL PRIMARY KEY, 
    [AccomadationId] INT NULL
)
