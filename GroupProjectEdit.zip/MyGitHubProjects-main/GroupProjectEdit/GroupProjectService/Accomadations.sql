﻿CREATE TABLE [dbo].[Accomdations]
(
	[Id] INT NOT NULL PRIMARY KEY
)
